/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   tracked_robot_plugin.cpp
 * Author: njy
 *
 * Created on July 13, 2020, 4:39 PM
 */

// Header file for C++
#include <stdio.h>
#include <functional>
#include <iostream>
#include <ros/ros.h>
#include <boost/bind.hpp>

// Header file for Gazebo and Ros

#include <gazebo/common/common.hh>
#include <gazebo/physics/physics.hh>
#include "sensor_msgs/Joy.h"
/*
#include <gazebo/common/Plugin.hh>
#include <gazebo/gazebo.hh>
#include <gazebo/sensors/sensors.hh>
#include <std_msgs/Float64.h>
#include <ignition/math/Vector3.hh>

#include "geometry_msgs/Twist.h"
*/
#define PI      3.141592
#define D2R     PI/180.
#define R2D     180./PI

namespace gazebo{
    class Tracked_Robot : public ModelPlugin{
        physics::LinkPtr Body;
        physics::LinkPtr Track_L_1;
        physics::LinkPtr Track_L_2;
        physics::LinkPtr Track_L_3;
        physics::LinkPtr Track_L_4;
        physics::LinkPtr Track_L_5;
        physics::LinkPtr Track_L_6;
        physics::LinkPtr Track_L_7;
        physics::LinkPtr Track_L_8;
        physics::LinkPtr Track_L_9;
        
        physics::LinkPtr Track_R_1;
        physics::LinkPtr Track_R_2;
        physics::LinkPtr Track_R_3;
        physics::LinkPtr Track_R_4;
        physics::LinkPtr Track_R_5;
        physics::LinkPtr Track_R_6;
        physics::LinkPtr Track_R_7;
        physics::LinkPtr Track_R_8;
        physics::LinkPtr Track_R_9;
        
        physics::LinkPtr Flipper_L;
        physics::LinkPtr Flipper_R;
        
        physics::LinkPtr Flipper_L_1;
        physics::LinkPtr Flipper_L_2;
        physics::LinkPtr Flipper_L_3;
        
        physics::LinkPtr Flipper_R_1;
        physics::LinkPtr Flipper_R_2;
        physics::LinkPtr Flipper_R_3;
        

        physics::JointPtr joint_Track_L_1;
        physics::JointPtr joint_Track_L_2;
        physics::JointPtr joint_Track_L_3;
        physics::JointPtr joint_Track_L_4;
        physics::JointPtr joint_Track_L_5;
        physics::JointPtr joint_Track_L_6;
        physics::JointPtr joint_Track_L_7;
        physics::JointPtr joint_Track_L_8;
        physics::JointPtr joint_Track_L_9;
        
        physics::JointPtr joint_Track_R_1;
        physics::JointPtr joint_Track_R_2;
        physics::JointPtr joint_Track_R_3;
        physics::JointPtr joint_Track_R_4;
        physics::JointPtr joint_Track_R_5;
        physics::JointPtr joint_Track_R_6;
        physics::JointPtr joint_Track_R_7;
        physics::JointPtr joint_Track_R_8;
        physics::JointPtr joint_Track_R_9;
        
        physics::JointPtr Joint_L;
        physics::JointPtr Joint_R;
        
        physics::JointPtr joint_Flipper_L_1;
        physics::JointPtr joint_Flipper_L_2;
        physics::JointPtr joint_Flipper_L_3;
        
        physics::JointPtr joint_Flipper_R_1;
        physics::JointPtr joint_Flipper_R_2;
        physics::JointPtr joint_Flipper_R_3;    
        
        physics::ModelPtr model;
        
        common::PID pidL;
        common::PID pidR;
        
        double trans = 0;
        //double delta_trans = 0;
        double yaw = 0;
        //double delta_yaw = 0;
        double vel_L = 0;
        double vel_R = 0;
        double flipper = 0;
        
        double angle_err_L = 0;
        double angle_err_R = 0;
        double tar_angle_L = 0;
        double tar_angle_R = 0;
        
        
        
        //ros topic 통신
        ros::NodeHandle nh;
        ros::Subscriber S_move;
        
        //setting for getting <dt>(=derivative time) 
        common::Time last_update_time;
        event::ConnectionPtr update_connection;
        double dt;
        double time = 0;
        
    public:
        void Load(physics::ModelPtr _model, sdf::ElementPtr /*_sdf*/); //로드함수
        void UpdateAlgorithm(); //주기적 반복 (1ms)
        void movecallback(const sensor_msgs::Joy::ConstPtr& msg)
        {
            trans = msg->axes[1]*10;
//            yaw = msg->axes[0]*5 + msg->axes[3]*10;
            yaw = msg->axes[0]*5;
            flipper = msg->axes[4] * (PI/4);
            if (flipper >= PI/4)
            {
                flipper = PI/4;
            }
            if (flipper <= -PI/4 )
            {
                flipper = -PI/4;
            }
        }
    };
    GZ_REGISTER_MODEL_PLUGIN(Tracked_Robot);
}


void gazebo::Tracked_Robot::Load(physics::ModelPtr _model, sdf::ElementPtr /*_sdf*/)
{
    this->model = _model;
    this->Body = this->model->GetLink("Body");
    this->Track_L_1 = this->model->GetLink("Track_L_1");
    this->Track_L_2 = this->model->GetLink("Track_L_2");
    this->Track_L_3 = this->model->GetLink("Track_L_3");
    this->Track_L_4 = this->model->GetLink("Track_L_4");
    this->Track_L_5 = this->model->GetLink("Track_L_5");
    this->Track_L_6 = this->model->GetLink("Track_L_6");
    this->Track_L_7 = this->model->GetLink("Track_L_7");
    this->Track_L_8 = this->model->GetLink("Track_L_8");
    this->Track_L_9 = this->model->GetLink("Track_L_9");
    this->Track_R_1 = this->model->GetLink("Track_R_1");
    this->Track_R_2 = this->model->GetLink("Track_R_2");
    this->Track_R_3 = this->model->GetLink("Track_R_3");
    this->Track_R_4 = this->model->GetLink("Track_R_4");
    this->Track_R_5 = this->model->GetLink("Track_R_5");
    this->Track_R_6 = this->model->GetLink("Track_R_6");
    this->Track_R_7 = this->model->GetLink("Track_R_7");
    this->Track_R_8 = this->model->GetLink("Track_R_8");
    this->Track_R_9 = this->model->GetLink("Track_R_9");
    
    this->Flipper_L = this->model->GetLink("Flipper_L");
    this->Flipper_R = this->model->GetLink("Flipper_R");
    this->Flipper_L_1 = this->model->GetLink("Flipper_L_1");
    this->Flipper_L_2 = this->model->GetLink("Flipper_L_2");
    this->Flipper_L_3 = this->model->GetLink("Flipper_L_3");
    this->Flipper_R_1 = this->model->GetLink("Flipper_R_1");
    this->Flipper_R_2 = this->model->GetLink("Flipper_R_2");
    this->Flipper_R_3 = this->model->GetLink("Flipper_R_3");
    
    this->joint_Track_L_1 = this->model->GetJoint("joint_Track_L_1");
    this->joint_Track_L_2 = this->model->GetJoint("joint_Track_L_2");
    this->joint_Track_L_3 = this->model->GetJoint("joint_Track_L_3");
    this->joint_Track_L_4 = this->model->GetJoint("joint_Track_L_4");
    this->joint_Track_L_5 = this->model->GetJoint("joint_Track_L_5");
    this->joint_Track_L_6 = this->model->GetJoint("joint_Track_L_6");
    this->joint_Track_L_7 = this->model->GetJoint("joint_Track_L_7");
    this->joint_Track_L_8 = this->model->GetJoint("joint_Track_L_8");
    this->joint_Track_L_9 = this->model->GetJoint("joint_Track_L_9");
    this->joint_Track_R_1 = this->model->GetJoint("joint_Track_R_1");
    this->joint_Track_R_2 = this->model->GetJoint("joint_Track_R_2");
    this->joint_Track_R_3 = this->model->GetJoint("joint_Track_R_3");
    this->joint_Track_R_4 = this->model->GetJoint("joint_Track_R_4");
    this->joint_Track_R_5 = this->model->GetJoint("joint_Track_R_5");
    this->joint_Track_R_6 = this->model->GetJoint("joint_Track_R_6");
    this->joint_Track_R_7 = this->model->GetJoint("joint_Track_R_7");
    this->joint_Track_R_8 = this->model->GetJoint("joint_Track_R_8");
    this->joint_Track_R_9 = this->model->GetJoint("joint_Track_R_9");
    
    this->Joint_L = this->model->GetJoint("Joint_L");
    this->Joint_R = this->model->GetJoint("Joint_R");
    
    this->joint_Flipper_L_1 = this->model->GetJoint("joint_Flipper_L_1");
    this->joint_Flipper_L_2 = this->model->GetJoint("joint_Flipper_L_2");
    this->joint_Flipper_L_3 = this->model->GetJoint("joint_Flipper_L_3");
    this->joint_Flipper_R_1 = this->model->GetJoint("joint_Flipper_R_1");
    this->joint_Flipper_R_2 = this->model->GetJoint("joint_Flipper_R_2");
    this->joint_Flipper_R_3 = this->model->GetJoint("joint_Flipper_R_3");
    
    this->pidL.Init(50, 0, 10, 200, -200, 1000, -1000);
    this->pidR.Init(50, 0, 10, 200, -200, 1000, -1000);
    

    this->last_update_time = this->model->GetWorld()->SimTime();
    this->update_connection = event::Events::ConnectWorldUpdateBegin(boost::bind(&Tracked_Robot::UpdateAlgorithm, this)); // Execute Gazebo Algorithm
    
    S_move = nh.subscribe<sensor_msgs::Joy>("joy", 100, &gazebo::Tracked_Robot::movecallback, this);
}

void gazebo::Tracked_Robot::UpdateAlgorithm()
{
        //* Calculate time  
    common::Time current_time = this->model->GetWorld()->SimTime();
    dt = current_time.Double() - this->last_update_time.Double();
    time = time + dt;
    
    vel_L = trans - yaw;
    vel_R = trans + yaw;
    
    this->joint_Track_L_1->SetVelocity(0,vel_L);
    this->joint_Track_L_2->SetVelocity(0,vel_L);
    this->joint_Track_L_3->SetVelocity(0,vel_L);
    this->joint_Track_L_4->SetVelocity(0,vel_L);
    this->joint_Track_L_5->SetVelocity(0,vel_L);
    this->joint_Track_L_6->SetVelocity(0,vel_L);
    this->joint_Track_L_7->SetVelocity(0,vel_L);
    this->joint_Track_L_8->SetVelocity(0,vel_L);
    this->joint_Track_L_9->SetVelocity(0,vel_L);
    this->joint_Flipper_L_1->SetVelocity(0,vel_L);
    this->joint_Flipper_L_2->SetVelocity(0,vel_L);
    this->joint_Flipper_L_3->SetVelocity(0,vel_L);
    
    this->joint_Track_R_1->SetVelocity(0,vel_R);
    this->joint_Track_R_2->SetVelocity(0,vel_R);
    this->joint_Track_R_3->SetVelocity(0,vel_R);
    this->joint_Track_R_4->SetVelocity(0,vel_R);
    this->joint_Track_R_5->SetVelocity(0,vel_R);
    this->joint_Track_R_6->SetVelocity(0,vel_R);
    this->joint_Track_R_7->SetVelocity(0,vel_R);
    this->joint_Track_R_8->SetVelocity(0,vel_R);
    this->joint_Track_R_9->SetVelocity(0,vel_R);
    this->joint_Flipper_R_1->SetVelocity(0,vel_R);
    this->joint_Flipper_R_2->SetVelocity(0,vel_R);
    this->joint_Flipper_R_3->SetVelocity(0,vel_R);
    
    tar_angle_L = -flipper;
    tar_angle_R = flipper;
    
    //angle error
    angle_err_L = this->Joint_L->Position(1) - tar_angle_L;
    angle_err_R = this->Joint_R->Position(1) - tar_angle_R;
    
    std::cout << "err_L: " << std::endl << angle_err_L << std::endl;
    std::cout << "err_R: " << std::endl << angle_err_R << std::endl;
    
    this->pidL.Update(angle_err_L, dt);
    this->pidR.Update(angle_err_R, dt);
    
    this->Joint_L->SetForce(1, this->pidL.GetCmd());
    this->Joint_R->SetForce(1, this->pidR.GetCmd());
    
    //this->joint_Track_L_3->SetForce(1,1);
    //this->joint_Track_R_3->SetForce(1,-1);

    
    this->last_update_time = current_time;
}
