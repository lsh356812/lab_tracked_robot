/*

Kubot package simulation code

kudos edu.ver

23.03.16

*/

//* Header file for C++
#include <stdio.h>
#include <iostream>
#include <boost/bind.hpp>
#include <time.h>

//* Header file for Gazebo and Ros
#include <gazebo/gazebo.hh>
#include <ros/ros.h>

#include <gazebo/common/common.hh> 
#include <gazebo/common/Plugin.hh> //model plugin gazebo API에서 확인 
#include <gazebo/physics/physics.hh> //우리는 ODE physics 사용 
#include <gazebo/sensors/sensors.hh> //IMU sensor 사용 

#include <std_msgs/Float32MultiArray.h>
#include <std_msgs/Int32.h>
#include <std_msgs/Float64.h>
#include <std_msgs/Float64MultiArray.h> //topic을 어떤 형태로 보내는지 

#include <functional>
#include <ignition/math/Vector3.hh>

#include <Eigen/Dense>

// KUDOS CKubot Header 파일 선언
#include "kudos/CKubot.h"
// #include "kudos/kinematics.h"


//* Print color
#define C_BLACK   "\033[30m"
#define C_RED     "\x1b[91m"
#define C_GREEN   "\x1b[92m"
#define C_YELLOW  "\x1b[93m"
#define C_BLUE    "\x1b[94m"
#define C_MAGENTA "\x1b[95m"
#define C_CYAN    "\x1b[96m"
#define C_RESET   "\x1b[0m"


using namespace std;
//여기까지가 책으로 따지자면 목차. namespace까지 

//Eigen//
using Eigen::MatrixXd;
using Eigen::VectorXd;
using Eigen::MatrixXf;
using Eigen::VectorXf;

using Eigen::Matrix2f;
using Eigen::Matrix3f;
using Eigen::Matrix4f;

using Eigen::Vector2f;
using Eigen::Vector3f;
using Eigen::Vector4f;
//Eigen 파일 안에 있는 namespace를 사용하겠다.
VectorXd test_vector_1(12);

namespace gazebo {

    class B_kubot_plugin : public ModelPlugin
    {
        //*** Variables for Kubot Simulation in Gazebo ***//
        //* TIME variable
        common::Time last_update_time;
        event::ConnectionPtr update_connection;
        double dt;
        double time = 0;

        physics::ModelPtr model; // model = _model 관련

        physics::JointPtr L_Hip_yaw_joint;
        physics::JointPtr L_Hip_roll_joint;
        physics::JointPtr L_Hip_pitch_joint;
        physics::JointPtr L_Knee_joint;
        physics::JointPtr L_Ankle_pitch_joint;
        physics::JointPtr L_Ankle_roll_joint;

        physics::JointPtr R_Hip_yaw_joint;
        physics::JointPtr R_Hip_roll_joint;
        physics::JointPtr R_Hip_pitch_joint;
        physics::JointPtr R_Knee_joint;
        physics::JointPtr R_Ankle_pitch_joint;
        physics::JointPtr R_Ankle_roll_joint;
        //* Index setting for each joint
        // physics::JointPtr L_Foot_joint;
        // physics::JointPtr R_Foot_joint;


        //* ROS Subscribe
        ros::NodeHandle nh; // ros 통신을 위한 node handle 선언 
        ros::Subscriber KubotMode;
        int ControlMode_by_ROS = 1;

        //* ROS Publish
        ros::Publisher KubotMode_pub;
        // ros::Publisher LHY_pub;
        // ros::Publisher LHR_pub;
        // ros::Publisher LHP_pub;
        // ros::Publisher LKN_pub;
        // ros::Publisher LAP_pub;
        // ros::Publisher LAR_pub;

        std_msgs::Float64 KubotMode_msg;     
        // std_msgs::Float64 LHY_msg;
        // std_msgs::Float64 LHR_msg;
        // std_msgs::Float64 LHP_msg;
        // std_msgs::Float64 LKN_msg;
        // std_msgs::Float64 LAP_msg;
        // std_msgs::Float64 LAR_msg;



        enum
        { //wst는 torso joint 같음
            LHY = 0, LHR, LHP, LKN, LAP, LAR, RHY, RHR, RHP, RKN, RAP, RAR
        };

        //* Joint Variables
        int nDoF; // Total degrees of freedom, except position and orientation of the robot
//구조체는 변수 집합이라고 생각하면 편하다.
        typedef struct RobotJoint //Joint variable struct for joint control 
        {
            double targetDegree; //The target deg, [deg]
            double targetRadian; //The target rad, [rad]
            double init_targetradian;

            double targetRadian_interpolation; //The interpolated target rad, [rad]

            double targetVelocity; //The target vel, [rad/s]
            double targetTorque; //The target torque, [N·m]

            double actualDegree; //The actual deg, [deg]
            double actualRadian; //The actual rad, [rad]
            double actualVelocity; //The actual vel, [rad/s]
            double actualRPM; //The actual rpm of input stage, [rpm]
            double actualTorque; //The actual torque, [N·m]

            double Kp;
            double Ki;
            double Kd;

        } ROBO_JOINT;
        ROBO_JOINT* joint;       

        bool joint_by_algorithm_update = false;
         

        //* Variables for IMU sensor
        sensors::SensorPtr Sensor;
        sensors::ImuSensorPtr IMU; //imu 센서 추가

        CKubot Kubot; // Kubot이라는 이름을 가진 CKubot class 선언함과 동시에 변수들을 다 갖고옴


        //* ROS Subscribe
        // ros::NodeHandle nh;
        // ros::Subscriber RoS_Mode;
        // ros::Subscriber Save_Mode;
        // int ControlMode_by_ROS = 0;
        // bool Balancing_Control_Mode_by_ROS = 0;

    public :
            //*** Functions for Kubot Simulation in Gazebo ***//
        void Load(physics::ModelPtr _model, sdf::ElementPtr /*_sdf*/); // Loading model data and initializing the system before simulation 
        void UpdateAlgorithm(); // Algorithm update while simulation
        
        void setjoints(); // Get each joint data from [physics::ModelPtr _model]    
        void getjointdata(); // Get encoder data of each joint
        
        void setsensor();
        void getsensordata();

        void jointcontroller();

        void initializejoint(); // 추가한
        void setjointPIDgain(); // 함수

        //*ROS subscribe
        // void ros_MODE(const std_msgs::Int32 &msg);          
        void KubotModeCallback(const std_msgs::Int32 &msg);
    };
    GZ_REGISTER_MODEL_PLUGIN(B_kubot_plugin);
    
}

void gazebo::B_kubot_plugin::KubotModeCallback(const std_msgs::Int32 &msg)
{
    // ROS_INFO("I heard: [%d]",msg.data);

    ControlMode_by_ROS = msg.data;
    

    switch (ControlMode_by_ROS) {

    case 1:
        Kubot.ControlMode = CTRLMODE_HOMEPOSE;
        printf("Kubot ready pose! \n");
        
        ControlMode_by_ROS = 0;
        Kubot.wave_run = 0;
        //Kubot.wave_cnt = 0;
        

        break;
    
    case 2:
        Kubot.ControlMode = CTRLMODE_WALKREADY;
        //Kubot.CommandFlag = GOTO_WALK_READY_POS;
        printf("WALK READY START! \n");
        


        Kubot.wave_cnt = 0;
        Kubot.wave_run = 1;
        ControlMode_by_ROS = 0;
        break;

    default:
         break;
    }

}


//model.sdf파일에 대한 정보를 불러오는 함수
void gazebo::B_kubot_plugin::Load(physics::ModelPtr _model, sdf::ElementPtr /*_sdf*/)
{
    //Kubot.ControlMode = CTRLMODE_WALKREADY; // wave 함수 초기
    Kubot.wave_cnt = 0;
    Kubot.wave_run = 0;
    printf("Load_do\n");
    KubotMode = nh.subscribe("/KubotMode",1,&gazebo::B_kubot_plugin::KubotModeCallback,this);

    //* ROS Subscribe
    // Save_Mode = nh.subscribe("save_step", 1, &gazebo::B_kubot_plugin::data_save_Execution, this);
    // RoS_Mode = nh.subscribe("rok_mode", 1, &gazebo::B_kubot_plugin::ros_MODE, this);
    
    //* model.sdf file based model data input to [physics::ModelPtr model] for gazebo simulation
    model = _model;

    setjoints();
    //sdf변환하기 전에 urdf파일에서 조인트가 몇개인지 인식을 함.
    //인식이 끝나면 joint 갯수에 맞게 구조체를 여러개 생성
    //Robotjoint 구조체를 joint 갯수만큼 복제되는 거임
    setsensor();


    nDoF = 12; // Get degrees of freedom, except position and orientation of the robot
    //우리가 만든 joint는 12개로 지정
    joint = new ROBO_JOINT[nDoF]; // Generation joint variables struct    
    
    initializejoint();
    setjointPIDgain();

        //ROS Publishers
    KubotMode_pub = nh.advertise<std_msgs::Float64>("command/KubotMode", 1000);           
    // LHY_pub = nh.advertise<std_msgs::Float64>("command_joint/LHY", 1000);//왼발 x좌표 ref값
    // LHR_pub = nh.advertise<std_msgs::Float64>("command_joint/LHR", 1000);//왼발 y좌표 ref값
    // LHP_pub = nh.advertise<std_msgs::Float64>("command_joint/LHP", 1000);
    // LKN_pub = nh.advertise<std_msgs::Float64>("command_joint/LKN", 1000);
    // LAP_pub = nh.advertise<std_msgs::Float64>("command_joint/LAP", 1000);
    // LAR_pub = nh.advertise<std_msgs::Float64>("command_joint/LHR", 1000);
    //* setting for getting dt
    last_update_time = model->GetWorld()->SimTime();
    update_connection = event::Events::ConnectWorldUpdateBegin(boost::bind(&B_kubot_plugin::UpdateAlgorithm, this));

}

void gazebo::B_kubot_plugin::UpdateAlgorithm()
{

    //* UPDATE TIME : 1ms
    //printf("update_do_time\n");
    common::Time current_time = model->GetWorld()->SimTime();
    dt = current_time.Double() - last_update_time.Double();
    //        cout << "dt:" << dt << endl;
    time = time + dt;
    //    cout << "time:" << time << endl;

    //* setting for getting dt at next step
    last_update_time = current_time;
    
    getjointdata();
    getsensordata();
    //printf("update_do_getdata\n");
    if(Kubot.wave_run == 1){        
        VectorXd init_radian_po(12);
        init_radian_po = Kubot.init_pose(Kubot.ControlMode, Kubot.actual_radian_vector, test_vector_1);
        for(int i=0;i<12;i++){
            joint[i].targetRadian = init_radian_po(i);

        }
    }
    //printf("update_do_init\n");

    static int con_count = 0;

    // Kubot.abc(); //Kubot class안에 만든 abc 실행
    // Kubot.FK();
    // Kubot.IK();

    jointcontroller();

    KubotMode_pub.publish(KubotMode_msg); 
  
}


void gazebo::B_kubot_plugin::setjoints() //plugin에다가 joints name 설정 .sdf파일에서 설정한 이름이랑 확인하기
{
    /*
     * Get each joints data from [physics::ModelPtr _model]
     */

    //* Joint specified in model.sdf
    L_Hip_yaw_joint = this->model->GetJoint("L_Hip_yaw_joint");
    L_Hip_roll_joint = this->model->GetJoint("L_Hip_roll_joint");
    L_Hip_pitch_joint = this->model->GetJoint("L_Hip_pitch_joint");
    L_Knee_joint = this->model->GetJoint("L_Knee_joint");
    L_Ankle_pitch_joint = this->model->GetJoint("L_Ankle_pitch_joint");
    L_Ankle_roll_joint = this->model->GetJoint("L_Ankle_roll_joint");

    R_Hip_yaw_joint = this->model->GetJoint("R_Hip_yaw_joint");
    R_Hip_roll_joint = this->model->GetJoint("R_Hip_roll_joint");
    R_Hip_pitch_joint = this->model->GetJoint("R_Hip_pitch_joint");
    R_Knee_joint = this->model->GetJoint("R_Knee_joint");
    R_Ankle_pitch_joint = this->model->GetJoint("R_Ankle_pitch_joint");
    R_Ankle_roll_joint = this->model->GetJoint("R_Ankle_roll_joint");


    //L_Foot_joint = this->model->GetJoint("L_Foot_joint");
    //R_Foot_joint = this->model->GetJoint("R_Foot_joint");
}

void gazebo::B_kubot_plugin::getjointdata()
{
    /*
     * Get encoder and velocity data of each joint[j].targetRadian = joint_h[j];
     * encoder unit : [rad] and unit conversion to [deg]
     * velocity unit : [rad/s] and unit conversion to [rpm]
     */
    joint[LHY].actualRadian = L_Hip_yaw_joint->Position(0);
    joint[LHR].actualRadian = L_Hip_roll_joint->Position(0);
    joint[LHP].actualRadian = L_Hip_pitch_joint->Position(0);
    joint[LKN].actualRadian = L_Knee_joint->Position(0);
    joint[LAP].actualRadian = L_Ankle_pitch_joint->Position(0);
    joint[LAR].actualRadian = L_Ankle_roll_joint->Position(0);

    joint[RHY].actualRadian = R_Hip_yaw_joint->Position(0);
    joint[RHR].actualRadian = R_Hip_roll_joint->Position(0);
    joint[RHP].actualRadian = R_Hip_pitch_joint->Position(0);
    joint[RKN].actualRadian = R_Knee_joint->Position(0);
    joint[RAP].actualRadian = R_Ankle_pitch_joint->Position(0);
    joint[RAR].actualRadian = R_Ankle_roll_joint->Position(0);
    //printf("before for \n");
    
    for (int j = 0; j < 12; j++) { //ndof -> 12
        joint[j].actualDegree = joint[j].actualRadian*R2D;
        
        test_vector_1(j) = joint[j].actualRadian;
        //printf("update_encorder\n");
        //Kubot.actual_radian_vector(j) = joint[j].actualRadian;
        //printf("vector_data : %lf \n", Kubot.actual_radian_vector(j));
        // printf(C_BLUE "joint[%d].actualRadian = %f\n" C_RESET, j, joint[j].actualRadian);
    }
    if (Kubot.wave_cnt == 0){
    Kubot.actual_radian_vector = test_vector_1;
    //printf("encorder_update \n");
    }
    //printf("complete for\n");
    joint[LHY].actualVelocity = L_Hip_yaw_joint->GetVelocity(0);
    joint[LHR].actualVelocity = L_Hip_roll_joint->GetVelocity(0);
    joint[LHP].actualVelocity = L_Hip_pitch_joint->GetVelocity(0);
    joint[LKN].actualVelocity = L_Knee_joint->GetVelocity(0);
    joint[LAP].actualVelocity = L_Ankle_pitch_joint->GetVelocity(0);
    joint[LAR].actualVelocity = L_Ankle_roll_joint->GetVelocity(0);

    joint[RHY].actualVelocity = R_Hip_yaw_joint->GetVelocity(0);
    joint[RHR].actualVelocity = R_Hip_roll_joint->GetVelocity(0);
    joint[RHP].actualVelocity = R_Hip_pitch_joint->GetVelocity(0);
    joint[RKN].actualVelocity = R_Knee_joint->GetVelocity(0);
    joint[RAP].actualVelocity = R_Ankle_pitch_joint->GetVelocity(0);
    joint[RAR].actualVelocity = R_Ankle_roll_joint->GetVelocity(0);

    for (int j = 0; j < nDoF; j++) {

        // printf(C_BLUE "joint[%d].targetVelocity = %f\n" C_RESET, j, joint[j].targetVelocity);
    }

    joint[LHY].actualTorque = L_Hip_yaw_joint->GetForce(0);
    joint[LHR].actualTorque = L_Hip_roll_joint->GetForce(0);
    joint[LHP].actualTorque = L_Hip_pitch_joint->GetForce(0);
    joint[LKN].actualTorque = L_Knee_joint->GetForce(0);
    joint[LAP].actualTorque = L_Ankle_pitch_joint->GetForce(0);
    joint[LAR].actualTorque = L_Ankle_roll_joint->GetForce(0);

    joint[RHY].actualTorque = R_Hip_yaw_joint->GetForce(0);
    joint[RHR].actualTorque = R_Hip_roll_joint->GetForce(0);
    joint[RHP].actualTorque = R_Hip_pitch_joint->GetForce(0);
    joint[RKN].actualTorque = R_Knee_joint->GetForce(0);
    joint[RAP].actualTorque = R_Ankle_pitch_joint->GetForce(0);
    joint[RAR].actualTorque = R_Ankle_roll_joint->GetForce(0);

    for (int j = 0; j < nDoF; j++) {

        joint[j].actualRPM = joint[j].actualVelocity * 60. / (2 * PI);
    }  

}


void gazebo::B_kubot_plugin::setsensor() //sdf파일에 있는 sensor를 설정하는 함수
{
        Sensor = sensors::get_sensor("IMU");
        IMU = std::dynamic_pointer_cast<sensors::ImuSensor>(Sensor);   
}

void gazebo::B_kubot_plugin::getsensordata()
{
     // IMU sensor data
        double IMUdata[3];

        IMUdata[0] = IMU->Orientation().Euler()[0];
        IMUdata[1] = IMU->Orientation().Euler()[1];
        IMUdata[2] = IMU->Orientation().Euler()[2];

        // printf(C_BLUE "IMU roll = %f\n" C_RESET, IMUdata[0]*R2D );
        // printf(C_RED "IMU pitch = %f\n" C_RESET, IMUdata[1]*R2D );
        // printf(C_YELLOW "IMU yaw = %f\n" C_RESET, IMUdata[2]*R2D );
        

        // IMU_dtheta[Roll] = IMU->AngularVelocity(false)[Roll];
        // IMU_dtheta[Pitch] = IMU->AngularVelocity(false)[Pitch];
        // IMU_dtheta[Yaw] = IMU->AngularVelocity(false)[Yaw];

}



void gazebo::B_kubot_plugin::jointcontroller()
{
    static double pre_rad[12];

    // double amp = 1;
    // double period = 3.0; // 이동하는 데 걸리는 시간 (주기)
    // double int_pos = 0.0;

    // double target_angle = cosWave(amp, period, time, int_pos);

    
    //     for (int j = 0; j < nDoF; j++) {

    //     joint[j].targetRadian = target_angle*joint[j].init_targetradian;
    //     joint[j].targetDegree = joint[j].targetRadian * R2D;
    //     joint[j].targetVelocity = (joint[j].targetRadian - pre_rad[j]) / dt;
    //     pre_rad[j] = joint[j].targetRadian;

    //     joint[j].targetTorque = (joint[j].Kp * (joint[j].targetRadian - joint[j].actualRadian)) \
    //                           + (joint[j].Kd * (joint[j].targetVelocity - joint[j].actualVelocity));
    //     }
    

    
        for (int j = 0; j < nDoF; j++) {
        joint[j].targetTorque = (joint[j].Kp * (joint[j].targetRadian - joint[j].actualRadian)) \
                              + (joint[j].Kd * (joint[j].targetVelocity - joint[j].actualVelocity));
        }
    
     
          

        //* Update target torque in gazebo simulation
        L_Hip_yaw_joint->SetForce(0, joint[LHY].targetTorque);
        L_Hip_roll_joint->SetForce(0, joint[LHR].targetTorque);
        L_Hip_pitch_joint->SetForce(0, joint[LHP].targetTorque);
        L_Knee_joint->SetForce(0, joint[LKN].targetTorque);
        L_Ankle_pitch_joint->SetForce(0, joint[LAP].targetTorque);        
        L_Ankle_roll_joint->SetForce(0, joint[LAR].targetTorque);         

        R_Hip_yaw_joint->SetForce(0, joint[RHY].targetTorque);
        R_Hip_roll_joint->SetForce(0, joint[RHR].targetTorque);
        R_Hip_pitch_joint->SetForce(0, joint[RHP].targetTorque);
        R_Knee_joint->SetForce(0, joint[RKN].targetTorque); 
        R_Ankle_pitch_joint->SetForce(0, joint[RAP].targetTorque);        
        R_Ankle_roll_joint->SetForce(0, joint[RAR].targetTorque); 

   
        //함수만 선언해놓고 함수를 실행안해서 아직은 실행불가
        //여기서 안돌아가는데 sdf파일 lower / upper 값 수정 필요 주석처리로 제한해제
        //괄호안을 0->2로 수정 x,y,z 순서라 그런가...

        
    


}




void gazebo::B_kubot_plugin::initializejoint()
{
    /*
     * Initialize joint variables for joint control
     */


        joint[0].init_targetradian  = (0  *D2R);     // L_Hip_yaw_joint
        joint[1].init_targetradian  = (0  *D2R);     // L_Hip_roll_joint
        joint[2].init_targetradian  = (-45*D2R);     // L_Hip_pitch_joint
        joint[3].init_targetradian  = (90 *D2R);     // L_Knee_joint
        joint[4].init_targetradian  = (-45*D2R);     // L_Ankle_pitch_joint
        joint[5].init_targetradian  = (0  *D2R);     // L_Ankle_roll_joint
        joint[6].init_targetradian  = (0  *D2R);     // R_Hip_yaw_joint
        joint[7].init_targetradian  = (0  *D2R);     // R_Hip_roll_joint
        joint[8].init_targetradian  = (-45*D2R);     // R_Hip_pitch_joint
        joint[9].init_targetradian  = (90 *D2R);     // R_Knee_joint
        joint[10].init_targetradian = (-45*D2R);     // R_Ankle_pitch_joint
        joint[11].init_targetradian = (0  *D2R);     // R_Ankle_roll_joint
    // for (int j = 0; j < nDoF; j++) {
    //     joint[j].targetDegree = 0;
    //     joint[j].targetRadian = 0;
    //     joint[j].targetVelocity = 0;
    //     joint[j].targetTorque = 0;
        
    //     joint[j].actualDegree = 0;
    //     joint[j].actualRadian = 0;
    //     joint[j].actualVelocity = 0;
    //     joint[j].actualRPM = 0;
    //     joint[j].actualTorque = 0;
    // }
}


void gazebo::B_kubot_plugin::setjointPIDgain()
{
    /*
     * Set each joint PID gain for joint control
     */
        joint[LHY].Kp = 150;
        joint[LHR].Kp = 150;
        joint[LHP].Kp = 150;
        joint[LKN].Kp = 150;
        joint[LAP].Kp = 150;
        joint[LAR].Kp = 150;

    joint[RHY].Kp = joint[LHY].Kp;
    joint[RHR].Kp = joint[LHR].Kp;
    joint[RHP].Kp = joint[LHP].Kp;
    joint[RKN].Kp = joint[LKN].Kp;
    joint[RAP].Kp = joint[LAP].Kp;
    joint[RAR].Kp = joint[LAR].Kp;

        joint[LHY].Kd = 0.1;
        joint[LHR].Kd = 0.1;
        joint[LHP].Kd = 0.1;
        joint[LKN].Kd = 0.1;
        joint[LAP].Kd = 0.1;
        joint[LAR].Kd = 0.1;

    joint[RHY].Kd = joint[LHY].Kd;
    joint[RHR].Kd = joint[LHR].Kd;
    joint[RHP].Kd = joint[LHP].Kd;
    joint[RKN].Kd = joint[LKN].Kd;
    joint[RAP].Kd = joint[LAP].Kd;
    joint[RAR].Kd = joint[LAR].Kd;

}
