#ifndef CKUBOT_H_
#define CKUBOT_H_


//* Basic header, Library
#include <stdio.h>
#include <iostream>
#include <string>


#include <Eigen/Dense>
#include <Eigen/Core>


using Eigen::MatrixXd;
using Eigen::VectorXd;
using Eigen::MatrixXf;
using Eigen::VectorXf;
using Eigen::Matrix3d;
using Eigen::Vector3d;

using Eigen::Vector2f;
using Eigen::Vector3f;
using Eigen::Vector4f;




#define PI      3.141592
#define D2R     PI/180.
#define R2D     180./PI 

#define onesecSize  100
#define tasktime    0.01

#define PatternPlan 4
#define PatternElement 6

#define MPC_GRF_N 5 // Control Horizon N for Model Predictive Control based Ground Reaction Force Control 


//* Command flag mode

typedef enum {
    NONE_ACT,
    RETURN_HOMEPOSE,
    GOTO_WALK_READY_POS,

    // Walking
    ACT_DSP,
    ACT_SSP,
    ACT_SSP_Mode,
    ACT_TEST_WALK,
    ACT_TESTING_WALK,
    ACT_STOPPING_WALK,
    ACT_STOP_WALK,
    ACT_START_WALK,
    ACT_CHANGE_WALK,
    ACT_INF_WALK,
    ACT_PATTERN_TEST,
    ACT_PATTERN_TESTING

} _COMMAND_FLAG;

//* Control Mode

typedef enum {
    CTRLMODE_NONE,
    CTRLMODE_HOMEPOSE,
    CTRLMODE_WALKREADY,
    CTRLMODE_WALKING,
    CTRLMODE_WALKING_TEST

} _CONTROL_MODE;

//* struct for Joints and End Points variables

typedef struct Joint {
    //* Current information

    float currentAngle; // [rad]
    float currentVel; // [rad/s]
    float currentAcc; // [rad/s^2]
    float currentTorque; // [N·m]

    //* Reference information

    float refAngle; //[rad]
    float refVel; // [rad/s]
    float refAcc; // [rad/s^2]
    float refTorque; // [N·m]
    float ctcTorque; // [N·m]

    float compensate_refAngle; // [rad]

    float walkReadyAngle; // [rad]

    float gain_scheme; // changed by pattern scheme
} JOINT;


class CKubot {
public:

    CKubot();
    CKubot(const CKubot& orig);
    virtual ~CKubot();

    //***Variables***//

    //* Control Mode and Command Flag

    unsigned int ControlMode;
    unsigned int CommandFlag;

    int joint_DoF; //Joint Degrees of Freedom


    //* enum

    enum JointNumber { // Kubot
        LHY = 0,
        LHR, LHP, LKN, LAP, LAR,
        RHY, RHR, RHP, RKN, RAP, RAR
    };

    enum EndPointAxis { // RoK-3's End point pos, ori axis
        X = 0, Y, Z, Roll, Pitch, Yaw
    };






    // int test = 10;
    int sign(double a);
    Eigen::Matrix3d transposeMat(Matrix3d mat);

    MatrixXd rotMatX(double q);
    MatrixXd rotMatY(double q);
    MatrixXd rotMatZ(double q);

    MatrixXd getTransformI0();
    MatrixXd getTransform6E();
    MatrixXd jointToTransform01(VectorXd q);
    MatrixXd jointToTransform01_R(VectorXd q);
    MatrixXd jointToTransform12(VectorXd q);
    MatrixXd jointToTransform23(VectorXd q);
    MatrixXd jointToTransform34(VectorXd q);
    MatrixXd jointToTransform45(VectorXd q);
    MatrixXd jointToTransform56(VectorXd q);

    MatrixXd jointToPosition(VectorXd q);
    MatrixXd jointToPosition_R(VectorXd q);
    Matrix3d jointToRotMat(VectorXd q);
    Matrix3d jointToRotMat_R(VectorXd q);
    VectorXd rotToEuler(MatrixXd rotMat);

    MatrixXd jointToPosJac(VectorXd q);
    MatrixXd jointToPosJac_R(VectorXd q);
    MatrixXd jointToRotJac(VectorXd q);
    MatrixXd jointToRotJac_R(VectorXd q);

    MatrixXd pseudoInverseMat(MatrixXd A, double lambda);
    VectorXd rotMatToRotVec(MatrixXd C);
    MatrixXd angleAxisToRotMat(VectorXd rotVec);
    MatrixXd jointToGeoJac(VectorXd q);
    MatrixXd jointToGeoJac_R(VectorXd q);
    VectorXd inverseKinematics(Vector3d r_des, Matrix3d C_des, VectorXd q0, double tol);
    VectorXd inverseKinematics_R(Vector3d r_des, Matrix3d C_des, VectorXd q0, double tol);
    VectorXd Geometric_IK_L(VectorXd GB_cfg, VectorXd GF_cfg);
    VectorXd Geometric_IK_R(VectorXd GB_cfg, VectorXd GF_cfg);

    //***Functions***//
    void abc();
    void FK();
    void IK();
    

    VectorXd init_pose(int param_1, VectorXd present, VectorXd real);
    int wave_cnt; // set wave start time
    int wave_run; // set wave runnung param
    VectorXd actual_radian_vector;

    // bool wave_flag;

    //* Functions related to Walking, are in CRobot_Walking.cpp

private:

    //***Variables***//    

    //***Functions***//

};
#endif
