#ifndef CKUBOT_H_
#define CKUBOT_H_


//* Basic header, Library
#include <stdio.h>
#include <iostream>
#include <string>


#include <Eigen/Dense>


using Eigen::MatrixXd;
using Eigen::VectorXd;
using Eigen::MatrixXf;
using Eigen::VectorXf;

#define PI      M_PI
#define R2D     180./PI
#define D2R     PI/180.

#define onesecSize  100
#define tasktime    0.01

#define PatternPlan 4
#define PatternElement 6

class CKubot {
public:

    CKubot();
    CKubot(const CKubot& orig);
    virtual ~CKubot();
    
    int test = 10;
    
    void CKubotinit();
    double FK();
    
private:

};
#endif
