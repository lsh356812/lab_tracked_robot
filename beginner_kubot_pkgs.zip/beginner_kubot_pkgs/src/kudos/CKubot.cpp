#include "CKubot.h"

using namespace std;

CKubot::CKubot()
{

}

CKubot::CKubot(const CKubot& orig)
{
}

CKubot::~CKubot()
{
}
void CKubot::CKubotinit(){
    printf("test_class\n");
}
